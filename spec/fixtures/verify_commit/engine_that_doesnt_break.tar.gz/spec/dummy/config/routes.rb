Rails.application.routes.draw do

  mount EngineThatDoesntBreak::Engine => "/"
end
