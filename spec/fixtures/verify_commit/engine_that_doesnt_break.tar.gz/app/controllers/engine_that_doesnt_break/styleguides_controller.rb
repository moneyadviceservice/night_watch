module EngineThatDoesntBreak
  class StyleguidesController < ApplicationController
  end
end
