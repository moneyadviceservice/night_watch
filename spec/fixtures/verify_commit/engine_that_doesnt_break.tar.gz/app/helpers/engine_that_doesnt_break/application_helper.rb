module EngineThatDoesntBreak
  module ApplicationHelper
  end
end
