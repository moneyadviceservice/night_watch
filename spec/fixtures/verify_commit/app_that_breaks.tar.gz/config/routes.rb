Rails.application.routes.draw do
  root to: 'styleguides#all'
end
