module EngineThatBreaks
  module ApplicationHelper
  end
end
