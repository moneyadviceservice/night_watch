EngineThatBreaks::Engine.routes.draw do
  resource :styleguide
end
