class StyleguidesController < ApplicationController
end
