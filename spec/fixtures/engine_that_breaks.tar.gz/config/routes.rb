EngineThatBreaks::Engine.routes.draw do
  resource :styleguide do
    get 'all'
  end

  root to: 'styleguides#all'
end
