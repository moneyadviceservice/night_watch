Rails.application.routes.draw do
  mount EngineThatBreaks::Engine => "/"
end
