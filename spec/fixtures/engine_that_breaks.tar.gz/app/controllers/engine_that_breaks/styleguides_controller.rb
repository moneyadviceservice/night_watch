module EngineThatBreaks
  class StyleguidesController < ApplicationController
  end
end
