module EngineThatBreaks
  class ApplicationController < ActionController::Base
  end
end
