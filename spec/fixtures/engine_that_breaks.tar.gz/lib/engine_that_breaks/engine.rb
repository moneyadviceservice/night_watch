module EngineThatBreaks
  class Engine < ::Rails::Engine
    isolate_namespace EngineThatBreaks

    initializer :assets do |app|
      app.config.assets.precompile += %w( engine_that_breaks_application.css )
    end
  end
end
