module EngineThatDoesntBreak
  class ApplicationController < ActionController::Base
  end
end
