module EngineThatDoesntBreak
  class Engine < ::Rails::Engine
    isolate_namespace EngineThatDoesntBreak
  end
end
